﻿# Architecture Overview

This diagram shows where Nono-Gate sits in a typical CI/CD pipeline.

Security Tools (Semgrep / CodeQL / SAST)
        │
        │ SARIF findings
        ▼
Nono-Gate Governance Engine
        │
        │ Deterministic policy evaluation
        ▼
Release Decision
        │
        │ Evidence construction
        ▼
Evidence Bundle + Governance Ledger
        │
        │ Independent verification
        ▼
Replay Verification
