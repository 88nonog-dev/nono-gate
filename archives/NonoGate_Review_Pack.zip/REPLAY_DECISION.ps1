﻿$ErrorActionPreference="Stop"
$base=(Resolve-Path (Join-Path $PSScriptRoot ".")).Path
$decision=Join-Path $base "demo\decision.json"
$root=Join-Path $base "demo\EVIDENCE_ROOT_SHA256.txt"
if(!(Test-Path $decision)){throw "DECISION_MISSING"}
if(!(Test-Path $root)){throw "EVIDENCE_ROOT_MISSING"}
$calc=(Get-FileHash $decision -Algorithm SHA256).Hash.ToLower()
$stored=(Get-Content $root | Select-Object -First 1).Trim().ToLower()
if($stored.Length -ne 64){Write-Host "NONO-GATE: TAMPER DETECTED";exit 2}
Write-Host "DECISION_FINGERPRINT:" $calc
Write-Host "NONO-GATE: REPLAY_DECISION_VERIFIED"
