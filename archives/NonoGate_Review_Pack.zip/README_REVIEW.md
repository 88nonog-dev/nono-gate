﻿# Nono-Gate Review Pack

This package is designed to allow security engineers to quickly evaluate the
Nono-Gate governance model.

Included:

RUN_PROOF_DEMO.ps1
run-proof.sh
ARCHITECTURE_OVERVIEW.md
WHY_NONO_GATE.md

Goal: allow reviewers to understand and reproduce the deterministic decision
pipeline with minimal effort.
