﻿# Nono-Gate Review Entry Point

This directory contains a minimal technical review package for Nono-Gate.

The goal is to allow security engineers to quickly understand and evaluate the
deterministic governance model implemented by the system.

Recommended review order:

1. QUICK_REVIEW.md

This short guide explains how to review the system in a few minutes.

Location:
docs/review-pack/QUICK_REVIEW.md

2. Architecture Overview

Understand where Nono-Gate sits inside a CI/CD pipeline.

docs/review-pack/ARCHITECTURE_OVERVIEW.md  
docs/review-pack/nono-gate-architecture.svg

3. Why Nono-Gate

Understand the governance problem the system addresses.

docs/review-pack/WHY_NONO_GATE.md

4. Threat Model

Understand which risks the architecture mitigates.

docs/review-pack/THREAT_MODEL.md

5. Example Inputs

examples/example.sarif  
examples/policy.json

6. Run Proof Demonstration

Execute:

RUN_PROOF_DEMO.ps1

Expected output:

DETERMINISTIC_DECISION_VERIFIED  
EVIDENCE_ROOT_MATCH  
LEDGER_INTEGRITY_OK

If these values appear, the reviewer has confirmed that the deterministic
decision and verification pipeline is operational.

This review pack is intentionally small and focused on demonstrating the
core governance architecture rather than providing a full production system.
