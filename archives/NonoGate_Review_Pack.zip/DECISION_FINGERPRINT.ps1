﻿$ErrorActionPreference="Stop"
$base=(Resolve-Path (Join-Path $PSScriptRoot ".")).Path
$decision=Join-Path $base "demo\decision.json"
if(!(Test-Path $decision)){throw "DECISION_MISSING"}
$hash=(Get-FileHash $decision -Algorithm SHA256).Hash.ToLower()
Write-Host "DECISION_FINGERPRINT:" $hash
