import fs from "fs";
import path from "path";
import crypto from "crypto";

function sha256File(p){
  const buf = fs.readFileSync(p);
  return crypto.createHash("sha256").update(buf).digest("hex");
}

export function writeEvidence(outDir, files){
  if(!fs.existsSync(outDir)) fs.mkdirSync(outDir,{recursive:true});

  const names = Object.keys(files).sort();

  for(const name of names){
    const fp = path.join(outDir,name);
    const v = files[name];
    if(typeof v === "string"){
      fs.writeFileSync(fp,v);
    } else {
      fs.writeFileSync(fp, JSON.stringify(v,null,2));
    }
  }

  const sums=[];
  for(const name of names){
    const fp = path.join(outDir,name);
    if(fs.statSync(fp).isFile()){
      const hash = sha256File(fp);
      sums.push(hash + "  " + name);
    }
  }

  fs.writeFileSync(path.join(outDir,"SHA256SUMS.txt"), sums.join("\n") + "\n");
  fs.writeFileSync(path.join(outDir,"manifest.json"), JSON.stringify({ files:names },null,2));
}
