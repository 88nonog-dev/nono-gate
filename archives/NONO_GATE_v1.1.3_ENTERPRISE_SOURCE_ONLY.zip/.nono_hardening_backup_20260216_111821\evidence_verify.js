import fs from "fs";
import path from "path";
import crypto from "crypto";

function sha256File(p){
  const buf = fs.readFileSync(p);
  return crypto.createHash("sha256").update(buf).digest("hex");
}

export function verifyBundle(bundleDir){

  const manPath = path.join(bundleDir,"manifest.json");
  const sumsPath = path.join(bundleDir,"SHA256SUMS.txt");

  if(!fs.existsSync(manPath)) throw new Error("MANIFEST_MISSING");
  if(!fs.existsSync(sumsPath)) throw new Error("SHA256SUMS_MISSING");

  const manifest = JSON.parse(fs.readFileSync(manPath,"utf-8"));
  const manifestFiles = manifest.files || [];

  const sumMap = new Map();
  const lines = fs.readFileSync(sumsPath,"utf-8")
    .split(/\r?\n/)
    .filter(Boolean);

  for(const line of lines){
    const hash = line.slice(0,64).toLowerCase();
    const file = line.slice(64).trim();
    if(hash.length === 64 && file){
      sumMap.set(file, hash);
    }
  }

  // Strict count check
  if(sumMap.size !== manifestFiles.length){
    throw new Error("SUM_COUNT_MISMATCH");
  }

  // Verify every manifest file
  for(const f of manifestFiles){
    const fp = path.join(bundleDir,f);

    if(!fs.existsSync(fp)) throw new Error("FILE_MISSING:"+f);
    if(!sumMap.has(f)) throw new Error("HASH_MISSING:"+f);

    const actual = sha256File(fp).toLowerCase();
    if(actual !== sumMap.get(f)) throw new Error("SHA_MISMATCH:"+f);
  }

  // Reject unexpected extra files
  const actualFiles = fs.readdirSync(bundleDir)
    .filter(f => f !== "manifest.json" && f !== "SHA256SUMS.txt");

  for(const f of actualFiles){
    if(!manifestFiles.includes(f)){
      throw new Error("UNEXPECTED_FILE:"+f);
    }
  }

  return true;
}
