import fs from "fs";
import path from "path";
import crypto from "crypto";

import { leafHashHex, merkleRoot } from "./merkle.js";

// ---- UTF-8 (no BOM) helpers ----
function writeTextUtf8NoBom(filePath, text) {
  const enc = new TextEncoder(); // UTF-8
  const bytes = enc.encode(text);
  fs.writeFileSync(filePath, Buffer.from(bytes));
}

function readTextUtf8(filePath) {
  return fs.readFileSync(filePath, "utf8");
}

// ---- Canonical JSON (deterministic) ----
function canonicalize(v) {
  if (v === null) return null;
  const t = typeof v;
  if (t === "number" || t === "boolean" || t === "string") return v;
  if (Array.isArray(v)) return v.map(canonicalize);
  if (t === "object") {
    const out = {};
    for (const k of Object.keys(v).sort()) out[k] = canonicalize(v[k]);
    return out;
  }
  return v;
}

function canonicalStringify(obj) {
  return JSON.stringify(canonicalize(obj));
}

function sha256HexUtf8(text) {
  return crypto.createHash("sha256").update(Buffer.from(text, "utf8")).digest("hex").toLowerCase();
}

// ---- Paths ----
export function getLedgerDir(rootDir) {
  const root = rootDir ? String(rootDir) : process.cwd();
  return path.join(root, ".nono", "ledger");
}

export function getLedgerFiles(rootDir) {
  const dir = getLedgerDir(rootDir);
  return {
    dir,
    entries: path.join(dir, "entries.ndjson"),
    checkpoints: path.join(dir, "checkpoints.ndjson"),
    latestCheckpoint: path.join(dir, "latest.checkpoint.json")
  };
}

export function ensureLedgerDir(rootDir) {
  const { dir } = getLedgerFiles(rootDir);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

// ---- Entry hash payload (per contract) ----
export function buildEntryHashPayload(entry) {
  if (!entry || typeof entry !== "object") throw new Error("ENTRY_INVALID");

  // v1 payload excludes created_utc to preserve determinism
  return {
    schema_id: String(entry.schema_id || ""),
    ledger_version: String(entry.ledger_version || ""),
    run_id: String(entry.run_id || ""),
    engine_version: String(entry.engine_version || ""),
    bundle_fingerprint_sha256: String(entry.bundle_fingerprint_sha256 || ""),
    root_anchor_sha256: String(entry.root_anchor_sha256 || ""),
    contract_sha256: String(entry.contract_sha256 || ""),
    architecture_sha256: String(entry.architecture_sha256 || ""),
    decision_sha256: String(entry.decision_sha256 || "")
  };
}

export function computeEntryLeafHex(entry) {
  const payload = buildEntryHashPayload(entry);
  const bytes = canonicalStringify(payload);
  return leafHashHex(bytes);
}

// ---- Append-only NDJSON ----
function appendNdjsonLine(filePath, obj) {
  const line = canonicalStringify(obj) + "\n";
  // append as UTF-8 no BOM
  fs.appendFileSync(filePath, line, { encoding: "utf8" });
}

export function readNdjson(filePath) {
  if (!fs.existsSync(filePath)) return [];
  const raw = readTextUtf8(filePath);
  const lines = raw.split(/\r?\n/).filter(Boolean);
  const out = [];
  for (const ln of lines) {
    out.push(JSON.parse(ln));
  }
  return out;
}

// ---- Entries ----
export function appendEntry(rootDir, entry) {
  ensureLedgerDir(rootDir);
  const f = getLedgerFiles(rootDir);

  const e = { ...entry };
  // caller may set created_utc; allowed but not hashed
  if (!e.schema_id) throw new Error("ENTRY_SCHEMA_ID_REQUIRED");
  if (!e.ledger_version) throw new Error("ENTRY_LEDGER_VERSION_REQUIRED");

  // compute leaf and store alongside entry (useful for fast receipts later)
  const entry_leaf_sha256 = computeEntryLeafHex(e);
  const stored = { ...e, entry_leaf_sha256 };

  appendNdjsonLine(f.entries, stored);
  return { entry: stored, entry_leaf_sha256 };
}

export function readEntries(rootDir) {
  const f = getLedgerFiles(rootDir);
  const arr = readNdjson(f.entries);
  return arr;
}

export function getLeafHexesFromEntries(entries) {
  return entries.map(e => {
    const h = (e && typeof e.entry_leaf_sha256 === "string" && e.entry_leaf_sha256.trim()) ? e.entry_leaf_sha256.trim().toLowerCase() : null;
    if (h) return h;
    return computeEntryLeafHex(e);
  });
}

// ---- Checkpoints ----
export function buildCheckpointHashPayload(cp) {
  return {
    schema_id: String(cp.schema_id || ""),
    ledger_version: String(cp.ledger_version || ""),
    tree_size: Number(cp.tree_size || 0),
    root_hash_sha256: String(cp.root_hash_sha256 || ""),
    prev_checkpoint_sha256: String(cp.prev_checkpoint_sha256 || "")
  };
}

export function computeCheckpointSha256(cp) {
  const payload = buildCheckpointHashPayload(cp);
  return sha256HexUtf8(canonicalStringify(payload));
}

export function appendCheckpoint(rootDir, checkpoint) {
  ensureLedgerDir(rootDir);
  const f = getLedgerFiles(rootDir);

  const cp = { ...checkpoint };
  if (!cp.schema_id) throw new Error("CHECKPOINT_SCHEMA_ID_REQUIRED");
  if (!cp.ledger_version) throw new Error("CHECKPOINT_LEDGER_VERSION_REQUIRED");

  cp.checkpoint_sha256 = computeCheckpointSha256(cp);

  appendNdjsonLine(f.checkpoints, cp);

  // latest checkpoint is derived; keep it updated for convenience
  writeTextUtf8NoBom(f.latestCheckpoint, JSON.stringify(cp, null, 2) + "\n");
  return cp;
}

export function readCheckpoints(rootDir) {
  const f = getLedgerFiles(rootDir);
  return readNdjson(f.checkpoints);
}

// ---- Build checkpoint from current entries (v1: checkpoint per run is allowed) ----
export function buildCheckpointFromLedger(rootDir, opts) {
  const options = opts || {};
  const schema_id = String(options.schema_id || "nono.transparency.checkpoint.v1");
  const ledger_version = String(options.ledger_version || "1.0.0");
  const created_utc = String(options.created_utc || new Date().toISOString());

  const cps = readCheckpoints(rootDir);
  const prev = cps.length ? cps[cps.length - 1].checkpoint_sha256 : "";

  const entries = readEntries(rootDir);
  const leafHexes = getLeafHexesFromEntries(entries);
  const mr = merkleRoot(leafHexes);

  const cp = {
    schema_id,
    ledger_version,
    created_utc,
    tree_size: mr.tree_size,
    root_hash_sha256: mr.root_hex,
    prev_checkpoint_sha256: prev
  };

  return cp;
}