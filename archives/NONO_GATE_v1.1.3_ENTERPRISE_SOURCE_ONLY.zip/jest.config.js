export default { testEnvironment: 'node' };
