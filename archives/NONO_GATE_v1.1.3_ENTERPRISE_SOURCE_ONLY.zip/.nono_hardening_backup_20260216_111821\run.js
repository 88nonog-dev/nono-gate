﻿import { ensureContract, hashContract } from './contract.js';
import fs from 'fs';
import path from 'path';
import { normalizeSarif } from './normalize.js';
import { diffIssues } from './diff.js';
import { loadPolicy, decide } from './policy.js';
import { writeEvidence } from './evidence.js';
import crypto from 'crypto';
import { sha256File, sha256Text } from './hash.js';

export async function run(args){
  const current = normalizeSarif(args.sarif);

  let baseline=[];
  if(args.baseline && fs.existsSync(args.baseline)){
    const raw = fs.readFileSync(args.baseline,'utf-8');
    baseline = raw ? JSON.parse(raw) : [];
  }

  const diff = diffIssues(current,baseline);
  const policy = loadPolicy(args.policy);
  const decision = decide(diff,policy);
  const contractPath = 'contract.json'; if(!fs.existsSync(contractPath)){ ensureContract(contractPath); }
  const policyPath = args.policy;

  const contractSha = sha256File(contractPath);
  const policySha = sha256File(policyPath);
  const bundleFingerprint = sha256Text(contractSha + policySha);
  decision.contract_sha256 = contractSha;
  decision.policy_sha256 = policySha;
  decision.bundle_fingerprint = bundleFingerprint;


  const runId = new Date().toISOString().replace(/[:.]/g,'-');
  const outDir = path.join('.nono','evidence',runId);

  const report =
`# Nono Gate Report

Status: ${decision.status}

New Issues: ${decision.new_count}

Severity:
${JSON.stringify(decision.severity||{},null,2)}

Stale Waivers: ${(decision.stale_waivers||[]).length}
`;

  const contractHash = hashContract(contractPath);
  decision.contract_sha256 = contractHash;
  decision.bundle_fingerprint = crypto.createHash('sha256').update(JSON.stringify(decision)).digest('hex');

  writeEvidence(outDir,{
    'baseline_used.json': baseline,
    'normalized.json': current,
    'diff.json': diff,
    'decision.json': decision,
    'report.md': report,
    'contract.json': decision.contract || {}
  });

  console.log('EVIDENCE_DIR='+outDir);
  process.exit(decision.status==='FAIL'?1:0);
}









