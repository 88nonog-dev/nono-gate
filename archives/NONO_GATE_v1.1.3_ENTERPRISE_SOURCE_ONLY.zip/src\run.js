import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

import { normalizeSarif } from './normalize.js';
import { diffIssues } from './diff.js';
import { loadPolicy, decide } from './policy.js';
import { writeEvidence } from './evidence.js';
import { ensureContract, hashContract } from './contract.js';
import { sha256Text } from './hash.js';

function readText(p){
  return fs.readFileSync(p,'utf-8');
}

function readJson(p){
  const raw = readText(p);
  const clean = raw && raw.length && raw.charCodeAt(0) === 0xFEFF ? raw.slice(1) : raw; // strip UTF-8 BOM if present
  return clean ? JSON.parse(clean) : null;
}

function canonicalize(v){
  if(v === null) return null;
  const t = typeof v;
  if(t === 'number' || t === 'boolean' || t === 'string') return v;
  if(Array.isArray(v)) return v.map(canonicalize);
  if(t === 'object'){
    const out = {};
    for(const k of Object.keys(v).sort()){
      out[k] = canonicalize(v[k]);
    }
    return out;
  }
  return v;
}

function canonicalStringify(v){
  return JSON.stringify(canonicalize(v));
}

function enforceStaging(staging){
  if(!fs.existsSync(staging)){
    throw new Error('STAGING_DIR_NOT_FOUND');
  }

  const required = new Set([
    'sarif.json',
    'normalized.json',
    'diff.json',
    'baseline_used.json',
    'core_run_meta.json'
  ]);

  const optional = new Set([
    'report.md',
    'fix_plan.json',
    'apply_log.txt',
    'results.sarif'
  ]);

  const entries = fs.readdirSync(staging);
  const found = new Set(entries);

  for(const r of required){
    if(!found.has(r)){
      throw new Error('STAGING_MISSING_REQUIRED:'+r);
    }
  }

  for(const f of found){
    if(!required.has(f) && !optional.has(f)){
      throw new Error('STAGING_UNEXPECTED_FILE:'+f);
    }
  }
}

function enforceCrossConsistency(staging){
  const sarifPath = path.join(staging, 'sarif.json');
  const normPath = path.join(staging, 'normalized.json');
  const diffPath = path.join(staging, 'diff.json');
  const basePath = path.join(staging, 'baseline_used.json');

  const stagedNormalized = readJson(normPath);
  const stagedDiff = readJson(diffPath);

  const baselineRaw = readJson(basePath);
  const baseline = Array.isArray(baselineRaw) ? baselineRaw : [];

  const computedNormalized = normalizeSarif(sarifPath);
  const computedDiff = diffIssues(computedNormalized, baseline);

  const sNorm = canonicalStringify(stagedNormalized);
  const cNorm = canonicalStringify(computedNormalized);
  if(sNorm !== cNorm){
    throw new Error('STAGING_DERIVATION_MISMATCH:normalized');
  }

  const sDiff = canonicalStringify(stagedDiff);
  const cDiff = canonicalStringify(computedDiff);
  if(sDiff !== cDiff){
    throw new Error('STAGING_DERIVATION_MISMATCH:diff');
  }
}

export async function run(args){

  const staging = args.staging ? String(args.staging) : null;

  if(staging){
    enforceStaging(staging);
    enforceCrossConsistency(staging);
  }

  let sarifInput = args.sarif;
  if(staging){
    sarifInput = path.join(staging, 'sarif.json');
  }

  const current = staging
    ? readJson(path.join(staging, 'normalized.json'))
    : normalizeSarif(sarifInput);

  const baseline = staging
    ? (Array.isArray(readJson(path.join(staging, 'baseline_used.json'))) ? readJson(path.join(staging, 'baseline_used.json')) : [])
    : (args.baseline && fs.existsSync(args.baseline)
        ? (Array.isArray(readJson(args.baseline)) ? readJson(args.baseline) : [])
        : []);

  const diff = staging
    ? readJson(path.join(staging, 'diff.json'))
    : diffIssues(current, baseline);

  const coreMeta = staging ? readJson(path.join(staging, 'core_run_meta.json')) : null;

  const policy = loadPolicy(args.policy);
  const decision = decide(diff, policy);

decision.engine_version = 'gate-1.1.0';

  const contractPath = 'contract.json';
  ensureContract(contractPath);
  const contractHash = hashContract(contractPath);
  decision.contract_sha256 = contractHash;

  const archPath = path.join(args.staging, 'ARCHITECTURE_STRICT_MODEL.md');
  const archShaPath = path.join(args.staging, 'ARCHITECTURE_SHA256.txt');
  if(fs.existsSync(archPath)){
    const archText = readText(archPath);
    const archActual = sha256Text(archText);
    if(fs.existsSync(archShaPath)){
      const archExpected = readText(archShaPath).trim();
      if(archExpected && archExpected !== archActual){
        throw new Error('ARCHITECTURE_SHA_MISMATCH');
      }
      decision.architecture_sha256 = archExpected || archActual;
    } else {
      fs.writeFileSync(archShaPath, archActual + '\n');
      decision.architecture_sha256 = archActual;
    }
  }

  const runId = args.runId ? String(args.runId) : new Date().toISOString().replace(/[:.]/g,'-');
  const outDir = path.join('.nono','evidence', runId);

  const report =
`# Nono Gate Report

Status: ${decision.status}

New Issues: ${decision.new_count}

Severity:
${JSON.stringify(decision.severity||{},null,2)}

Stale Waivers: ${(decision.stale_waivers||[]).length}

Contract SHA256: ${decision.contract_sha256 || ''}

Architecture SHA256: ${decision.architecture_sha256 || ''}

Staging: ${staging || ''}
`;

  decision.bundle_fingerprint = sha256Text(JSON.stringify(decision));

  const rootAnchor = sha256Text(
    (decision.bundle_fingerprint || '') + '|' +
    (decision.contract_sha256 || '') + '|' +
    (decision.architecture_sha256 || '')
  ) + '\n';

  const contractRaw = fs.readFileSync(contractPath,'utf-8');

  const evidenceFiles = {
    'baseline_used.json': baseline,
    'normalized.json': current,
    'diff.json': diff,
    'core_run_meta.json': coreMeta === null ? {} : coreMeta,
    'decision.json': decision,
    'report.md': report,
    'contract.json': contractRaw,
    'BUNDLE_ROOT_SHA256.txt': rootAnchor
  };

  writeEvidence(outDir, evidenceFiles);
  // ---- DETERMINISTIC MANIFEST (non-circular) ----
  const files = fs.readdirSync(outDir)
    .filter(f => f !== 'SHA256SUMS.txt')
    .sort();

  const lines = [];

  for (const f of files) {
    const full = path.join(outDir, f);
    const buf = fs.readFileSync(full);
    const hash = crypto.createHash('sha256').update(buf).digest('hex');
    lines.push(hash + '  ' + f);
  }

  fs.writeFileSync(
    path.join(outDir, 'SHA256SUMS.txt'),
    lines.join('\n') + '\n',
    { encoding: 'utf8' }
  );


  console.log('EVIDENCE_DIR='+outDir);
  return { decision, outDir };
}
