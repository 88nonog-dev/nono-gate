import fs from "fs";
import path from "path";
import crypto from "crypto";
import child_process from "child_process";

import { appendEntry, buildCheckpointFromLedger, appendCheckpoint, ensureLedgerDir, getLedgerDir } from "./ledgerStore.js";
import { buildReceiptForIndex, verifyReceiptBasic } from "./receipt.js";

function sha256HexUtf8(text){
  return crypto.createHash("sha256").update(Buffer.from(text,"utf8")).digest("hex").toLowerCase();
}

function writeUtf8NoBom(filePath, text){
  const enc = new TextEncoder();
  const bytes = enc.encode(text);
  fs.writeFileSync(filePath, Buffer.from(bytes));
}

function tryMinisignSign(messagePath, sigPath){
  // Opt-in by providing secret key path via env.
  // We NEVER store keys, only read path from env at runtime.
  const secret = process.env.NONO_MINISIGN_SECRET_KEY ? String(process.env.NONO_MINISIGN_SECRET_KEY) : "";
  const pub = process.env.NONO_MINISIGN_PUBLIC_KEY ? String(process.env.NONO_MINISIGN_PUBLIC_KEY) : "";
  const exe = process.env.NONO_MINISIGN_EXE ? String(process.env.NONO_MINISIGN_EXE) : "minisign";

  if(!secret) return { signed:false, reason:"NO_SECRET_KEY_ENV" };
  if(!fs.existsSync(secret)) return { signed:false, reason:"SECRET_KEY_PATH_NOT_FOUND" };
  if(!fs.existsSync(messagePath)) return { signed:false, reason:"MESSAGE_NOT_FOUND" };

  try{
    // minisign -S -s <secretkey> -m <message> -x <signature>
    child_process.execFileSync(exe, ["-S","-s",secret,"-m",messagePath,"-x",sigPath], { stdio:"pipe" });
  } catch (e){
    return { signed:false, reason:"MINISIGN_FAILED" };
  }

  // Optionally copy pub key into ledger dir for independent verifiers
  let pubCopied = "";
  try{
    if(pub && fs.existsSync(pub)){
      const ledgerDir = getLedgerDir(process.cwd());
      ensureLedgerDir(process.cwd());
      const dst = path.join(ledgerDir, "LEDGER_PUBLIC_KEY.minisign.pub");
      fs.copyFileSync(pub, dst);
      pubCopied = dst;
    }
  } catch (_) { /* ignore */ }

  return { signed:true, sigPath, pubKeyPath: pubCopied || "" };
}

export async function finalizeWithLedger(result, runId){

  if(!result || !result.decision || !result.outDir){
    throw new Error("FINALIZE_INVALID_RESULT");
  }

  const decision = result.decision;
  const outDir = result.outDir;

  const decision_sha256 = sha256HexUtf8(JSON.stringify(decision));

  const entry = {
    schema_id: "nono.transparency.entry.v1",
    ledger_version: "1.0.0",
    created_utc: new Date().toISOString(),
    run_id: String(runId || ""),
    engine_version: String(decision.engine_version || ""),
    bundle_fingerprint_sha256: String(decision.bundle_fingerprint || ""),
    // v1: root anchor currently derived from decision.bundle_fingerprint (kept deterministic)
    root_anchor_sha256: String(decision.bundle_fingerprint || ""),
    contract_sha256: String(decision.contract_sha256 || ""),
    architecture_sha256: String(decision.architecture_sha256 || ""),
    decision_sha256
  };

  appendEntry(process.cwd(), entry);

  const cpObj = buildCheckpointFromLedger(process.cwd(), {
    schema_id: "nono.transparency.checkpoint.v1",
    ledger_version: "1.0.0",
    created_utc: new Date().toISOString()
  });

  const cpStored = appendCheckpoint(process.cwd(), cpObj);

  // --- Produce a signed checkpoint artifact inside the evidence directory (optional) ---
  const checkpointPath = path.join(outDir, "CHECKPOINT.json");
  writeUtf8NoBom(checkpointPath, JSON.stringify(cpStored, null, 2) + "\n");

  const sigPath = path.join(outDir, "CHECKPOINT.minisig");
  const sigInfo = tryMinisignSign(checkpointPath, sigPath);

  const receipt = buildReceiptForIndex(process.cwd(), cpStored);
  // attach signature metadata (optional fields)
  receipt.checkpoint_signature = {
    algo: "minisign",
    signed: !!sigInfo.signed,
    reason: sigInfo.signed ? "" : (sigInfo.reason || "UNSIGNED"),
    signature_file: sigInfo.signed ? "CHECKPOINT.minisig" : "",
    public_key_file: sigInfo.pubKeyPath ? "LEDGER_PUBLIC_KEY.minisign.pub" : ""
  };

  verifyReceiptBasic(receipt);

  const receiptPath = path.join(outDir, "TRANSPARENCY_RECEIPT.json");
  writeUtf8NoBom(receiptPath, JSON.stringify(receipt, null, 2) + "\n");

  return receipt;
}