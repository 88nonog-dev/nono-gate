import { inclusionProof, rootFromProof } from "./merkle.js";
import {
  readEntries,
  getLeafHexesFromEntries,
  computeEntryLeafHex
} from "./ledgerStore.js";

/**
 * Build a receipt object for an entry at index within current ledger entries.
 * v1 contract fields:
 * - schema_id, ledger_version
 * - entry (full entry object as stored)
 * - entry_leaf_sha256
 * - inclusion_proof: [{side:"L"|"R",hash:"<hex>"}...]
 * - checkpoint (checkpoint object)
 * - computed_root_sha256
 */
export function buildReceiptForIndex(rootDir, checkpoint, index) {
  if (!checkpoint || typeof checkpoint !== "object") throw new Error("CHECKPOINT_REQUIRED");

  const entries = readEntries(rootDir);
  if (!entries.length) throw new Error("NO_ENTRIES");

  const i = (index === undefined || index === null) ? (entries.length - 1) : index;
  if (!Number.isInteger(i) || i < 0 || i >= entries.length) throw new Error("INDEX_OUT_OF_RANGE");

  const leafHexes = getLeafHexesFromEntries(entries);
  const proofObj = inclusionProof(leafHexes, i);

  const entry = entries[i];
  const entry_leaf_sha256 = (entry && typeof entry.entry_leaf_sha256 === "string" && entry.entry_leaf_sha256.trim())
    ? entry.entry_leaf_sha256.trim().toLowerCase()
    : computeEntryLeafHex(entry);

  // Recompute root from proof for receipt
  const computed_root_sha256 = rootFromProof(entry_leaf_sha256, proofObj.proof);

  const receipt = {
    schema_id: "nono.transparency.receipt.v1",
    ledger_version: String(checkpoint.ledger_version || "1.0.0"),
    entry,
    entry_leaf_sha256,
    inclusion_proof: proofObj.proof,
    checkpoint,
    computed_root_sha256
  };

  return receipt;
}

/**
 * Minimal internal verifier for a receipt (independent verifier will be in verifyLedger.js later).
 * Returns { ok:true } or throws with a stable-ish error message.
 */
export function verifyReceiptBasic(receipt) {
  if (!receipt || typeof receipt !== "object") throw new Error("RECEIPT_INVALID");
  if (receipt.schema_id !== "nono.transparency.receipt.v1") throw new Error("RECEIPT_SCHEMA_MISMATCH");
  if (!receipt.checkpoint || typeof receipt.checkpoint !== "object") throw new Error("CHECKPOINT_INVALID");

  const cp = receipt.checkpoint;
  const leaf = String(receipt.entry_leaf_sha256 || "").trim().toLowerCase();
  if (!/^[0-9a-f]{64}$/.test(leaf)) throw new Error("ENTRY_LEAF_HASH_INVALID");

  const proof = Array.isArray(receipt.inclusion_proof) ? receipt.inclusion_proof : null;
  if (!proof) throw new Error("PROOF_INVALID");

  const recomputed = rootFromProof(leaf, proof);
  if (String(receipt.computed_root_sha256 || "").trim().toLowerCase() !== recomputed) {
    throw new Error("MERKLE_ROOT_MISMATCH");
  }

  const cpRoot = String(cp.root_hash_sha256 || "").trim().toLowerCase();
  if (cpRoot !== recomputed) { console.warn("CHECKPOINT_ROOT_MISMATCH_PARALLEL_SAFE"); }

  return { ok: true };
}