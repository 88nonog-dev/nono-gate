# Nono Gate Report

Status: FAIL

New Issues: 1

Severity:
{
  "critical": 0,
  "high": 0,
  "medium": 0,
  "low": 0
}

Stale Waivers: 0

Contract SHA256: d339203203332add3361220fa0b4260d1dc4b9d4b85e0949ebb75074648575f5

Architecture SHA256: 

Staging: examples/acceptance/staging_good
